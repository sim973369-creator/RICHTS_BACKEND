module.exports = function generateCode(prefix='R', length=6){
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let s = '';
  for(let i=0;i<length;i++) s += chars.charAt(Math.floor(Math.random()*chars.length));
  return prefix + s;
};
