const fetch = require('node-fetch');

const getAccessToken = async (clientId, clientSecret, mode='sandbox')=>{
  if(!clientId || !clientSecret) throw new Error('PayPal credentials missing');
  const base = mode === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
  const auth = Buffer.from(clientId + ':' + clientSecret).toString('base64');
  const res = await fetch(base + '/v1/oauth2/token', {
    method:'POST',
    headers:{
      'Authorization':'Basic ' + auth,
      'Content-Type':'application/x-www-form-urlencoded'
    },
    body:'grant_type=client_credentials'
  });
  if(!res.ok) throw new Error('Failed to get PayPal token');
  const data = await res.json();
  return data.access_token;
};

module.exports = { getAccessToken };
