const mongoose = require('mongoose');
const uri = process.env.MONGO_URI;
const connectDB = async ()=> {
  if(!uri) {
    console.warn('MONGO_URI not set in .env');
    return;
  }
  try {
    await mongoose.connect(uri, { });
    console.log('MongoDB connected');
  } catch(err){
    console.error('MongoDB connection error:', err.message);
    process.exit(1);
  }
};
module.exports = connectDB;
