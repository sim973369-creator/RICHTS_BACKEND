const Card = require('../models/Card');
const generateCode = require('../utils/generateCode');

exports.list = async (req,res)=>{
  const cards = await Card.find();
  res.json(cards);
};

exports.create = async (req,res)=>{
  const {title,type,price,reward,quantity=1} = req.body;
  const items = [];
  for(let i=0;i<quantity;i++){
    const c = new Card({title,type,price,reward,code:generateCode(type?type.substring(0,1).toUpperCase():'C')});
    await c.save();
    items.push(c);
  }
  res.json({created:items.length});
};

exports.buy = async (req,res)=>{
  const {cardId, userId} = req.body;
  const card = await Card.findById(cardId);
  if(!card) return res.status(404).json({msg:'card not found'});
  if(card.sold) return res.status(400).json({msg:'already sold'});
  card.sold = true;
  card.owner = userId;
  await card.save();
  res.json({msg:'card reserved', card});
};
