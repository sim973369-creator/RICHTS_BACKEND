const { getAccessToken } = require('../config/paypal');
const Payment = require('../models/Payment');

exports.createOrder = async (req,res)=>{
  try{
    const {amount} = req.body;
    const clientId = process.env.PAYPAL_CLIENT_ID;
    const secret = process.env.PAYPAL_CLIENT_SECRET;
    if(!clientId || !secret) return res.status(500).json({msg:'PayPal credentials missing'});
    const token = await getAccessToken(clientId, secret, process.env.PAYPAL_MODE || 'sandbox');
    const orderId = 'ORDER-' + Math.random().toString(36).substring(2,12).toUpperCase();
    const p = new Payment({amount, provider:'paypal', providerData:{orderId}, status:'created'});
    await p.save();
    res.json({orderId});
  }catch(err){
    res.status(500).json({error:err.message});
  }
};

exports.captureOrder = async (req,res)=>{
  try{
    const {orderId} = req.body;
    const payment = await Payment.findOne({'providerData.orderId': orderId});
    if(!payment) return res.status(404).json({msg:'order not found'});
    payment.status = 'captured';
    await payment.save();
    res.json({msg:'captured', orderId});
  }catch(err){ res.status(500).json({error:err.message}); }
};
