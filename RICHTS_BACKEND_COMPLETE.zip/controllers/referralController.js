const Referral = require('../models/Referral');
const User = require('../models/User');

exports.create = async (req,res)=>{
  const {referrerId, referredId} = req.body;
  const r = new Referral({referrer:referrerId, referred:referredId, code:'REF'+Math.floor(Math.random()*10000)});
  await r.save();
  res.json(r);
};

exports.list = async (req,res)=>{
  const items = await Referral.find().populate('referrer referred','email');
  res.json(items);
};
