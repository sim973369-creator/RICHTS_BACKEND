const Card = require('../models/Card');
const User = require('../models/User');

const checkAdminToken = (req)=>{
  const token = req.headers['authorization'] ? req.headers['authorization'].replace('Bearer ','') : null;
  return token && token === (process.env.ADMIN_TOKEN || 'change_admin_token');
};

exports.addFreeCardsToUser = async (req,res)=>{
  if(!checkAdminToken(req)) return res.status(401).json({msg:'unauthorized'});
  const {userId, quantity=1, title='Bonus Card', type='bonus'} = req.body;
  const user = await User.findById(userId);
  if(!user) return res.status(404).json({msg:'no user'});
  const created = [];
  for(let i=0;i<quantity;i++){
    const c = new (require('../models/Card'))({title,type,price:0,reward:0,code:'BONUS'+Math.floor(Math.random()*10000), owner:user._id});
    await c.save();
    user.cards.push(c._id);
    created.push(c);
  }
  await user.save();
  res.json({added:created.length});
};
