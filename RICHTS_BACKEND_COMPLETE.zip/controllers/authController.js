const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req,res)=>{
  try{
    const {email,password,code} = req.body;
    if(!email) return res.status(400).json({msg:'email required'});
    let user = await User.findOne({email});
    if(user) return res.status(400).json({msg:'user exists'});
    user = new User({email});
    if(password){
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(password,salt);
    }
    if(code) user.code = code;
    await user.save();
    res.json({msg:'user created', userId:user._id});
  }catch(err){ res.status(500).json({error:err.message}); }
};

exports.login = async (req,res)=>{
  try{
    const {email,password} = req.body;
    if(!email) return res.status(400).json({msg:'email required'});
    const user = await User.findOne({email});
    if(!user) return res.status(400).json({msg:'no user'});
    if(user.password){
      const ok = await bcrypt.compare(password,user.password);
      if(!ok) return res.status(401).json({msg:'invalid'});
    }
    const token = jwt.sign({id:user._id}, process.env.JWT_SECRET || 'secret', {expiresIn:'30d'});
    res.json({token, userId:user._id});
  }catch(err){ res.status(500).json({error:err.message}); }
};
