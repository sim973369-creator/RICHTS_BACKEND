# RICHTS Backend (Express + MongoDB + PayPal placeholder)

See .env.example and start with `npm install` then `npm start`.
