const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/paypalController');
router.post('/create-order', ctrl.createOrder);
router.post('/capture-order', ctrl.captureOrder);
module.exports = router;
