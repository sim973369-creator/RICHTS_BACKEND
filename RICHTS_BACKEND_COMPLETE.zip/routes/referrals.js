const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/referralController');
router.post('/create', ctrl.create);
router.get('/', ctrl.list);
module.exports = router;
