const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/adminController');
router.post('/add-free-cards', ctrl.addFreeCardsToUser);
module.exports = router;
