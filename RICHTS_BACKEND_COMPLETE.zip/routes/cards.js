const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/cardController');
router.get('/', ctrl.list);
router.post('/create', ctrl.create);
router.post('/buy', ctrl.buy);
module.exports = router;
