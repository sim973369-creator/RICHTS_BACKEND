const mongoose = require('mongoose');
const ReferralSchema = new mongoose.Schema({
  referrer:{type:mongoose.Schema.Types.ObjectId, ref:'User'},
  referred:{type:mongoose.Schema.Types.ObjectId, ref:'User'},
  code:String,
  used:Boolean
},{timestamps:true});
module.exports = mongoose.model('Referral', ReferralSchema);
