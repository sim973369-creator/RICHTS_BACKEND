const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  email:{type:String, required:true, unique:true},
  password:{type:String},
  referrals:[{type:mongoose.Schema.Types.ObjectId, ref:'Referral'}],
  cards:[{type:mongoose.Schema.Types.ObjectId, ref:'Card'}],
  balance:{type:Number, default:0},
  isAdmin:{type:Boolean, default:false},
  code:{type:String}
},{timestamps:true});
module.exports = mongoose.model('User', UserSchema);
