const mongoose = require('mongoose');
const CardSchema = new mongoose.Schema({
  title:String,
  type:String,
  price:Number,
  reward:Number,
  code:String,
  sold:{type:Boolean, default:false},
  owner:{type:mongoose.Schema.Types.ObjectId, ref:'User', default:null}
},{timestamps:true});
module.exports = mongoose.model('Card', CardSchema);
